/* 
 * File:   main.cpp
 * Author: Kyle J. Janosky
 * Created on July 22, 2015, 12:14 PM
 * Purpose: To read a file 
 */

//System Libraries 
#include <iostream>
#include <fstream>
#include <cstdlib>
using namespace std;

//User Libraries

//Global Constants 

//Function Prototype 

//Execution begins here!
int main(int argc, char** argv) {
    //Declare Variables 
    int num,max,min;
    string test,sNum;
    
    ifstream infile("number.txt");

    infile.getline(sNum,400);
    
    //while(!infile.eof()){
        //infile>>test;
        //cout<<test << " ";
    //}
    
    //Exit Stage Right!
    return 0;
}
