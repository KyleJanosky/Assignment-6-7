/* 
 * File:   main.cpp
 * Author: Manjot Dhindsa/Kyle J. Janosky Collaboration
 * Created on July 23, 2015, 12:55 PM
 * Purpose: Homework
 */

//System Libraries
#include <iostream>
using namespace std; //std namespace-> iostream

//User Libraries

//Global constants

//Function Prototypes
char grd(char [],float);

//Execution Begins Here!
int main(int argc, char** argv){
    //Declare Variables
    const int  NSIZE=4;       //Size of array containing 0-3
    const int  SIZE=5;        //Size of array containing 0-4
    string     name[SIZE];    //String array of 5 students
    char       grade[SIZE]=
               {'A','B','C',
               'D','f'};      //Char array of grades received
    float      stun1[NSIZE],  //Grades of 4 tests for student 1
               stun2[NSIZE],  //Grades of 4 tests for student 2
               stun3[NSIZE],  //Grades of 4 tests for student 3
               stun4[NSIZE],  //Grades of 4 tests for student 4
               stun5[NSIZE];  //Grades of 4 tests for student 5
    float      average;       //Average of students test scores
    float      total;         //Total score of four tests
    
    //Ask user for the names of the five students
    cout<<"Please enter the names of your five students."<<endl;
    for(int i=0;i<SIZE;i++){
        cin>>name[i];
    }
    
    //Ask user to enter the scores the students got.
    cout<<"Now enter the scores each student received on their 4 tests."<<endl;
    for(int i=0;i<SIZE;i++){
        cout<<name[i]<<" received these scores: ";
        for(int j=0;j<NSIZE;j++){
            if(i==0){
                cin>>stun1[j];
            }else if(i==1){
                cin>>stun2[j];
            }else if(i==2){
                cin>>stun3[j];
            }else if(i==3){
                cin>>stun4[j];
            }else if(i==4){
                cin>>stun5[j];
            }
        }
    }
    
    //Find the average
    for(int i=0;i<SIZE;i++){
        cout<<"The average score for "<<name[i]<<" is: ";
        for(int j=0;j<1;j++){
            if(i==0){
                total=stun1[0]+stun1[1]+stun1[2]+stun1[3];
                average=total/NSIZE;
                cout<<average<<" and your grade is "<<grd(grade,average)<<endl;
            }else if(i==1){
               total=stun2[0]+stun2[1]+stun2[2]+stun2[3];
               average=total/NSIZE;
               cout<<average<<" and your grade is "<<grd(grade,average)<<endl;
            }else if(i==2){
               total=stun3[0]+stun3[1]+stun3[2]+stun3[3];
               average=total/NSIZE;
               cout<<average<<" and your grade is "<<grd(grade,average)<<endl;
            }else if(i==3){
               total=stun4[0]+stun4[1]+stun4[2]+stun4[3];
               average=total/NSIZE;
               cout<<average<<" and your grade is "<<grd(grade,average)<<endl;
            }else if(i==4){
               total=stun5[0]+stun5[1]+stun5[2]+stun5[3];
               average=total/NSIZE;
               cout<<average<<" and your grade is "<<grd(grade,average)<<endl;
            }
        }
    }
    

    return 0;
}

char grd(char grade[],float average){
    if(average>=0&&average<=59){
       cout<<grade[4];
    }else if(average>=60&&average<=69){
        cout<<grade[3];
    }else if(average>=70&&average<=79){
        cout<<grade[2];
    }else if(average>=80&&average<=89){
        cout<<grade[1];
    }else if(average>=90&&average<=100){
        cout<<grade[0];
    }
}
