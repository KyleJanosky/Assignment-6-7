/* 
 * File:   main.cpp
 * Author: Manjot Dhindsa/Kyle J. Janosky Collaboration
 * Created on July 23, 2015, 12:08 PM
 * Purpose: Homework
 */

//System Libraries
#include <iostream>
#include <iomanip>
using namespace std; //std namespace-> iostream

//User Libraries

//Global constants

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    const int      SIZE=7;        //Size for the array
    unsigned short hours[SIZE];   //Hours worked by employees
    float          payRate[SIZE]; //Hourly pay of each employee
    float          wages[SIZE];   //Each employees gross wage
    int empId[SIZE]={5658845,4520125,7895122,
                     8777541,8451277,1302850,
                     7580489};    //Employees id.
    
    //Find the hours worked and pay rate for each employee.
    for(int i=0;i<SIZE;i++){
        cout<<"For employee #"<<empId[i]<<" enter the hours worked. ";
        cin>>hours[i];
        cout<<"Also enter the employees hourly pay rate. $";
        cin>>payRate[i];
        cout<<endl;
    }
    
    //Now find the wages of each employee
    for(int i=0;i<SIZE;i++){
        wages[i]=hours[i]*payRate[i];
        cout<<"The wages for employees #"<<empId[i]<<
              " is = $"<<wages[i]<<endl;
    }

    //Exit Stage Right!
    return 0;
}

