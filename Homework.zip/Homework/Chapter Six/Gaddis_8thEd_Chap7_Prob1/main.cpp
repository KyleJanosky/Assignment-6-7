/* 
 * File:   main.cpp
 * Author: Manjot Dhindsa/Kyle J. Janosky Collaboration
 * Created on July 23, 2015, 12:08 PM
 * Purpose: Homework
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global constants

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    int min;       //holds the smallest value
    int max;       //holds the largest value
    const int Num;  //constant set as an integer Num = 10
    int a[Num];    //holds the 10 values in array
    
    //sorts out the given values
    for(int i=0;i<10;i++){
        cout<< "\nPlease Enter the values one after the other(max of 10): ";
        cin>> a[i]; 
    }
    
    min=a[0]; 
    max=a[0];
    for(int i=1;i<10;i++){
        if(min>a[i]){
            min=a[i];
        }else if(max<a[i]){
            max = a[i];
        }
    } 
    
    //Output results
    cout<<"The largest number is: "<< max << endl;
    cout<<"The smallest number is: "<< min << endl; 

    //Exit Stage Right!
    return 0;
}

